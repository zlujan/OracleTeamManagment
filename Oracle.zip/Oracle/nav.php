<!DOCTYPE html>
<html>
<head>
   <title> Edgar Arroyo's Team Management System </title>  
   <link href="css/style.css" rel = "stylesheet" type = "text/css">         
</head>
<body>
     <!--Side nav Bar-->
   <div class="wrapper">
       <div class="sidenav">
               <ul class="favorites">
                   <li><font size="5">Favorites</font></li>
                   <hr width = 99%>
                   <li><a href="index.php">Dashboard</a></li>
                   <li><a href="taskcenter.php">Task Center</a></li>
                   <li><a href="pmgmt.php">Project Management</a><li>
               </ul> 
               <!-- <ul class="projects">
                   <li><font size="5">Projects</font></li>
                   <hr width = 99%>
                   <li><a href="#C4">Import Project</a></li>
                   <li><a href="ManageProject.php">Manage Project</a></li>
               </ul> -->
       </div>
         <!-- Top left image of navigation-->
       <div class = "box6">
            <div class = "box1">
                <a href="index.php"><img src="images/oracle2.png" alt="oracle" style="width: 400px; height: 100px;"></a>
            </div>
            <div class = "box2">
                <div class = "box3"><h1>Edgar Arroyo's <br> Team Management System</h1></div>
            </div>
       </div>

   <!-- </div> -->
