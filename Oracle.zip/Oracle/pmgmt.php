<?php include("nav.php"); ?>

       <!-- Project management page, with multiple project cards.-->
     <div class="box10">

          <!-- card for project 1-->
          <a href="ManageProjectRead.php" target="_blank">         
            <div class="card" >
              <div class="card-header"><b>&nbsp;&nbsp;&nbsp;&nbsp;Project 1</b><hr width="100%", color="black"></div>        
                <div class="card-body">
                  <h5 class="card-title">PID: XXXX <br>Project Name:XXXXX</h5>
                  <p class="card-text"></p>
              </div>
            </div>
          </a>
          
          <!-- card for project 2-->
          <a href="ManageProjectRead2.php" target="_blank">         
            <div class="card">
              <div class="card-header"><b>&nbsp;&nbsp;&nbsp;&nbsp;Project 2</b><hr width="100%", color="black"></div>        
                <div class="card-body">
                  <h5 class="card-title">PID: XXXX <br>Project Name:XXXXX</h5>
                  <p class="card-text"></p>
              </div>
            </div>
          </a>
          
           <!-- card for project 3-->
          <a href="ManageProjectRead3.php" target="_blank">         
            <div class="card" >
              <div class="card-header"><b>&nbsp;&nbsp;&nbsp;&nbsp;Project 3</b><hr width="100%", color="black"></div>        
                <div class="card-body">
                  <h5 class="card-title">PID: XXXX <br>Project Name:XXXXX</h5>
                  <p class="card-text"></p>
              </div>
            </div>
          </a>
           <!--an infinite number of cards can be put in to this page to reference more DB tables -->
     </div>

</div>

</body>
</html>